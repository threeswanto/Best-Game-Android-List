class Constants {
  static const String SplashTitle = "Best Game Android";
  static const String SplashCredits = "Powered by Yoko";
}