class PathAssets {
  static const SplashLogo = "assets/splash_logo.png";
}
