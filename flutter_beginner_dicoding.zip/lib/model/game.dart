class Game {
  String gameName;
  String gameImage;
  String gameDeveloper;
  String gameDescription;

  Game(
      {this.gameName,
      this.gameImage,
      this.gameDeveloper,
      this.gameDescription});
}
